# category: 브루트 포스
N, M = map(int, input().split())
lst = list(map(int, input().split()))

ans = 0     # 변수를 생성할때는 위치/초기값 고민 후 작성!!
# N개중 몇 개의 요소를 뽑아서 만드는 모든 조합의 경우의 수!!(이 툴은 암기를 해야한다!!)
for i in range(N-2): #i를 뽑고, 나머지 뽑을 요소 2개를 위한 자리 마련을 고려해서 N-2로 설정...
    for j in range(i+1, N-1): #j는 i+1이후부터 넣을 수 있고, 이 이후에 뽑을 k를 위한 자리마련으로 N-1로 설정.
        for k in range(j+1, N): # k는 j+1이후부터 넣을 수 있고, 이 이후에는 뽑을 것이 없으니 lst 열의 끝자리의 idx까지 순회할 수 있음!
            if ans<lst[i]+lst[j]+lst[k]<=M: #ans를 M보다 작으면서도, 그 범위 안에서 max값을 찾기 위해, 계속 갱신 시킨다는 느낌임!!
                ans = lst[i]+lst[j]+lst[k]
print(ans)